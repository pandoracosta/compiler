#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <map>
#include <fstream>
#include <ctype.h>
using namespace std;
int main() {
  int i, state=0;
  FILE *fp; char c;
  fp = fopen("test.txt","r");
  vector <string> reservadas = {"ATEH","SE","BIT","DE", "ENQUANTO", "ESCREVA", "FIM", "FUNCAO", "INICIO", "INTEIRO", "LEIA", "NULO", "PARA", "PARE", "REAL", "RECEBA", "SE", "SENAO", "VAR", "VET"}
  vector <pair<int,string>> TOKENS; // 0/reservada, 1/id, 2/num
  while (!feof(fp)) {
    fscanf(fp,"%c",&c);
    while(1) {
      switch (state) {
        string temp = "";
        case 0:
          if (isalpha(c) != 0) 
            state = 1;
          else if (c=='!')
            state = 2;
          else if (c=='.')
            state = 3;
          else if (c==':')
            state = 4;
          else if (c==';')
            state = 5;
          else if (c=='<')
            state = 6;
          else if (c== '=')
            state = 7;
          else if (c=='>')
            state = 8;
          else if (c == '+')
            state = 9;
          else if (c=='-')
            state = 10;
          else if (c =='*')
            state = 11;
          else if (c=='/')
            state = 12;
          else if (c=='%')
            state = 13;
          else if (c=='(')
            state = 14;
          else if (c==')')
            state = 15;
          else if (c=='[')
            state = 16;
          else if (c==']')
            state = 17;
          else if (c=='"')
            state = 18;
          else if (c=='&')
            state = 19;
          else if (c=='|')
            state = 20;
          else if (c=='0' || c=='1' || c=='2' || c=='3' || c=='4' || c=='5' || c=='6' || c=='7' || c=='8' || c=='9') {
            state = 21;
          }
          else fail();
          break;
      case 1:
        fp++;
        fscanf(fp,"%c",&c);
        if (isalpha(c)) {
          temp+=c;
          for (i=0; i<reservadas.size(); i++) {
            if (reservadas[i].compare(temp)==0) {
              TOKENS.push_back(make_pair(0,temp));
              temp="";
              state = 0;
              break;
            }
            else
              state = 1; 
          }    
        }
        else if (c==' ')
          state = 22;
        else {
          TOKENS.push_back(make_pair(1,temp));
          temp="";
          state = 0;
        }
        break;

       } 
    }
  }  
}